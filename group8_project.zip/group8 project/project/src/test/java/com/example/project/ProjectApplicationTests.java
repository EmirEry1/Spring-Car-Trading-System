package com.example.project;


import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.example.project.dto.CarDTO;
import com.example.project.dto.MakeReservationDTO;
import com.example.project.dto.RentedCarDTO;
import com.example.project.model.Car;
import com.example.project.model.Reservation;
import com.example.project.repository.CarRepository;
import com.example.project.repository.ReservationRepository;
import com.example.project.repository.ServiceRepository;
import com.example.project.service.CarService;
import com.example.project.service.ReservationService;



@SpringBootTest
class ProjectApplicationTests {

	@Autowired
	ReservationService reservationService;
	
	@Autowired
	CarService carService;
	
	@Autowired
	CarRepository carRepository;
	
	@Autowired
	ReservationRepository reservationRepository;
	
	@Autowired
	ServiceRepository serviceRepository;
	

	//Car with id 1
	@Test
	public void testMakeReservationMethod() {
		List<Integer> equipmentIds= new ArrayList<Integer>();
		equipmentIds.add(101);
		equipmentIds.add(102);
		List<Integer> serviceIds= new ArrayList<Integer>();
		serviceIds.add(101);
		serviceIds.add(103);
		MakeReservationDTO dto = reservationService.makeReservation("5a2b8c9d", 10, 101, 101, 102, equipmentIds, serviceIds);
		Reservation r = reservationRepository.findByReservationNumber(dto.getReservationNumber());
		assertEquals(r.getCar().getBarcode(),"5a2b8c9d");
	}
	
	//Cars with id 4 and 5
	@Test
	public void testSearchAvailableCars() {
		List<CarDTO> cars = carService.searchAvailableCars("Sedan", "Manuel");
		System.out.println("***************************************");
		System.out.println(cars.get(1).getBarcode());
		assertEquals(2,cars.size());
	}
	
	@Test
	public void testReturnCar(){
		List<Integer> equipmentIds= new ArrayList<Integer>();
		equipmentIds.add(101);
		List<Integer> serviceIds= new ArrayList<Integer>();
		serviceIds.add(101);
		MakeReservationDTO dto = reservationService.makeReservation("6r85f8g7",15, 102, 101, 101, equipmentIds, serviceIds);
		reservationService.returnTheCar(dto.getReservationNumber());
		Car c = carRepository.findByBarcode("6r85f8g7");
		assertEquals("Available",c.getStatus());
	}
	
	
	@Test
	public void testCancelReservation(){
		List<Integer> equipmentIds= new ArrayList<Integer>();
		equipmentIds.add(101);
		List<Integer> serviceIds= new ArrayList<Integer>();
		serviceIds.add(101);
		MakeReservationDTO dto = reservationService.makeReservation("4e8d7c2v",15, 102, 101, 101, equipmentIds, serviceIds);
		reservationService.cancelReservation(dto.getReservationNumber());
		Car c = carRepository.findByBarcode("4e8d7c2v");
		Reservation r = reservationRepository.findByReservationNumber(dto.getReservationNumber());
		boolean b = c.getStatus() == "Available" &&  r.getStatus() == "CANCELLED";
		assertEquals(r.getStatus() ,  "CANCELLED");
		assertEquals(c.getStatus(), "Available");
	}
	
	//BMW
	@Test
	public void testDeleteCar(){
		Car c = carRepository.findByBarcode("9d5f2e1d");
		carService.delete("9d5f2e1d");
		Car cTest = carRepository.findByBarcode(c.getBarcode());
		assertEquals(cTest,null);
	}
	
	//Volvo
	
	@Transactional
	@Test
	public void testAddAdditionalService(){
		List<Integer> equipmentIds= new ArrayList<Integer>();
		equipmentIds.add(104);
		List<Integer> serviceIds= new ArrayList<Integer>();
		serviceIds.add(102);
		MakeReservationDTO rDto = reservationService.makeReservation("3b6c4j8q", 7, 101, 102, 102, equipmentIds, serviceIds);
		reservationService.addAdditionalServiceToReservation(rDto.getReservationNumber(),103);
		Reservation r = reservationRepository.findByReservationNumber(rDto.getReservationNumber());
		//ReservationDTO dtos = reservationService.findAllReservations().get(3);
		int size= r.getServices().size();
		assertEquals(2,size);
	}
	
	@Transactional
	@Test
	public void testAddAdditionalEquipment(){
		List<Integer> equipmentIds= new ArrayList<Integer>();
		equipmentIds.add(104);
		List<Integer> serviceIds= new ArrayList<Integer>();
		serviceIds.add(102);
		MakeReservationDTO rDto = reservationService.makeReservation("3b6c4j8q", 7, 101, 102, 102, equipmentIds, serviceIds);
		reservationService.addAdditionalEquipmentToReservation(rDto.getReservationNumber(),103);
		Reservation r = reservationRepository.findByReservationNumber(rDto.getReservationNumber());
		assertEquals(2,r.getEquipments().size());
	}
	
	@Test
	public void testGetAllRentedCars() {
		List<RentedCarDTO> cars = carService.getAllRentedCars();
		System.out.println(cars.get(0).getBarcode());
		assertEquals(1,cars.size());
		
	}
}
