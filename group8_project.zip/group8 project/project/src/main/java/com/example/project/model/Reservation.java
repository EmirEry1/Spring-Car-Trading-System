package com.example.project.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;


@Entity
public class Reservation {
	@Id
	private int reservationNumber;
	private LocalDate creationDate;
	private LocalDateTime pickUpDateAndTime;
	private LocalDateTime dropOffDateAndTime;
	
	@ManyToOne
	private Location pickUpLocation;
	@ManyToOne
	private Location dropOffLocation;
	private LocalDate returnDate;
	private String status;
	
	
	@ManyToOne (cascade = {CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH})
	private Car car;

	@ManyToOne (cascade = {CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH})
	private Member member;
	
	@ManyToMany (cascade = {CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH})
	private List<Service> services;
	
	@ManyToMany (cascade = {CascadeType.MERGE,CascadeType.PERSIST, CascadeType.REFRESH})
	private List<Equipment> equipments;

	public int getReservationNumber() {
		return reservationNumber;
	}
	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	public List<Equipment> getEquipments() {
		return equipments;
	}

	public void setEquipments(List<Equipment> equipments) {
		this.equipments = equipments;
	}

	public void setReservationNumber(int reservationNumber) {
		this.reservationNumber = reservationNumber;
	}

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public LocalDateTime getPickUpDateAndTime() {
		return pickUpDateAndTime;
	}

	public void setPickUpDateAndTime(LocalDateTime pickUpDateAndTime) {
		this.pickUpDateAndTime = pickUpDateAndTime;
	}

	public LocalDateTime getDropOffDateAndTime() {
		return dropOffDateAndTime;
	}

	public void setDropOffDateAndTime(LocalDateTime dropOffDateAndTime) {
		this.dropOffDateAndTime = dropOffDateAndTime;
	}

	public Location getPickUpLocation() {
		return pickUpLocation;
	}

	public void setPickUpLocation(Location pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}

	public Location getDropOffLocation() {
		return dropOffLocation;
	}

	public void setDropOffLocation(Location dropOffLocation) {
		this.dropOffLocation = dropOffLocation;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}


}
