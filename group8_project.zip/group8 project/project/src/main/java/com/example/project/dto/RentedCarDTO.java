package com.example.project.dto;

import java.time.LocalDateTime;

import com.example.project.model.Location;

public class RentedCarDTO {
	private String brand;
	private String model;
	private String type;
	private String transmissionType;
	private String barcode;
	private int reservationNumber;
	private String memberName;
	private LocalDateTime dropOffDateAndTime;
	private Location dropOffLocation;
	private int reservationDayCount;
	
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTransmissionType() {
		return transmissionType;
	}
	public void setTransmissionType(String transmissionType) {
		this.transmissionType = transmissionType;
	}
	public String getBarcode() {
		return barcode;
	}
	public void setBarcode(String barcode) {
		this.barcode = barcode;
	}
	public int getReservationNumber() {
		return reservationNumber;
	}
	public void setReservationNumber(int reservationNumber) {
		this.reservationNumber = reservationNumber;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public LocalDateTime getDropOffDateAndTime() {
		return dropOffDateAndTime;
	}
	public void setDropOffDateAndTime(LocalDateTime dropOffDateAndTime) {
		this.dropOffDateAndTime = dropOffDateAndTime;
	}
	public Location getDropOffLocation() {
		return dropOffLocation;
	}
	public void setDropOffLocation(Location dropOffLocation) {
		this.dropOffLocation = dropOffLocation;
	}
	public int getReservationDayCount() {
		return reservationDayCount;
	}
	public void setReservationDayCount(int reservationDayCount) {
		this.reservationDayCount = reservationDayCount;
	}
	
}
