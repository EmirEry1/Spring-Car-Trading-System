package com.example.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.dto.LocationDTO;
import com.example.project.mapper.LocationMapper;
import com.example.project.model.Location;
import com.example.project.repository.LocationRepository;


@Service
public class LocationService {
	@Autowired
	LocationRepository locationRepository;

	public LocationDTO create(LocationDTO dto){
		Location location=LocationMapper.DTOtoLocation(dto);
    	locationRepository.save(location);
    	return LocationMapper.locationToDTO(location);
		/*locationRepository.save(l);
		Location location = locationRepository.findById(l.getId());
		LocationDTO dto = LocationMapper.locationToDTO(location);		
		return dto;		*/
	}
	
	public LocationDTO findById(int id){
		Location location = locationRepository.findById(id);
		if(location!=null) {
			return LocationMapper.locationToDTO(location);
		}
        return null;
	}
	
	public List<LocationDTO> findAllLocations(){
		List<Location> locations = locationRepository.findAll();
		List<LocationDTO> locationDTOs = new ArrayList<LocationDTO>();
		if(!locations.isEmpty()) {
			for(int i = 0; i<locations.size();i++) {
				locationDTOs.add(LocationMapper.locationToDTO(locations.get(i)));
			}
		}
		else {
			return null;
		}
		return locationDTOs;
	}

}
