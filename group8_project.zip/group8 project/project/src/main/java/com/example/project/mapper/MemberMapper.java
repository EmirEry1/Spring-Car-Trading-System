package com.example.project.mapper;


import com.example.project.dto.MemberDTO;
import com.example.project.model.Member;

public class MemberMapper {
	public static MemberDTO memberToDTO(Member member) {
		MemberDTO dto= new MemberDTO();
		//dto.setId(member.getId());
		dto.setName(member.getName());
		dto.setPhone(member.getPhone());
		dto.setLicenceNumber(member.getLicenceNumber());
		dto.setAddress(member.getAddress());
		dto.setEmail(member.getEmail());
		return dto;
	}
	public static Member DTOtoMember(MemberDTO dto) {
		Member member= new Member();
		member.setName(dto.getName());
		member.setPhone(dto.getPhone());
		member.setLicenceNumber(dto.getLicenceNumber());
		member.setAddress(dto.getAddress());
		member.setEmail(dto.getEmail());
		return member;
	}

}
