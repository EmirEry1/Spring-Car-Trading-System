package com.example.project.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.dto.MakeReservationDTO;
import com.example.project.dto.ReservationDTO;
import com.example.project.mapper.MakeReservationMapper;
import com.example.project.mapper.ReservationMapper;
import com.example.project.model.Car;
import com.example.project.model.Equipment;
import com.example.project.model.Reservation;

import com.example.project.repository.CarRepository;
import com.example.project.repository.EquipmentRepository;
import com.example.project.repository.LocationRepository;
import com.example.project.repository.MemberRepository;
import com.example.project.repository.ReservationRepository;
import com.example.project.repository.ServiceRepository;

import jakarta.transaction.Transactional;

@Service
public class ReservationService {
	@Autowired
	ReservationRepository reservationRepository;
	@Autowired
	LocationRepository locationRepository;
	@Autowired
	MemberRepository memberRepository;
	@Autowired
	CarRepository carRepository;
	@Autowired
	ServiceRepository serviceRepository;
	@Autowired
	EquipmentRepository equipmentRepository;
	
	public ReservationDTO create(ReservationDTO dto){
		Reservation reservation = ReservationMapper.DTOtoReservation(dto);
		reservationRepository.save(reservation);		
		return ReservationMapper.reservationToDTO(reservation);		
	}
	
	public ReservationDTO findById(int id){
		Reservation r = reservationRepository.findByReservationNumber(id);
		if(r!=null){
			ReservationDTO dto = ReservationMapper.reservationToDTO(r);		
			return dto;
		}
		return null;
	}
	
	public List<ReservationDTO> findAllReservations(){
		List<Reservation> reservations = reservationRepository.findAll();
		List<ReservationDTO> reservationDTOs = new ArrayList<ReservationDTO>();
		if(!reservations.isEmpty()) {
			for(int i = 0; i<reservations.size();i++) {
				reservationDTOs.add(ReservationMapper.reservationToDTO(reservations.get(i)));
			}
		}
		else {
			return null;
		}
		return reservationDTOs;
	}
	
	@Transactional
	public MakeReservationDTO makeReservation(String carBarcode, int dayCount, int memberId, int pickUpLocationCode, int dropOffLocationCode, List<Integer> equipmentIds, List<Integer> serviceIds) {
		
		if(!carRepository.findByBarcode(carBarcode).getStatus().equals("Available")) {
			return null;
		}
		int number = (int)(Math.random()*100000000);
		while(reservationRepository.findByReservationNumber(number)!=null) {
			number++;
		}
		List<com.example.project.model.Service> services = new ArrayList<com.example.project.model.Service>();
		for(int i = 0; i<serviceIds.size(); i++) {
			int id = serviceIds.get(i);
			com.example.project.model.Service service = serviceRepository.findById(id);
			services.add(service);
		}
		List<Equipment> equipments = new ArrayList<Equipment>();
		for(int i = 0; i<equipmentIds.size(); i++) {
			int id = equipmentIds.get(i);
			Equipment equipment = equipmentRepository.findById(id);
			equipments.add(equipment);
		}
		Reservation r = new Reservation();
		r.setReservationNumber(number);
		r.setCreationDate(java.time.LocalDate.now());
		r.setPickUpDateAndTime(java.time.LocalDateTime.now().plusDays(1));
		r.setDropOffDateAndTime(java.time.LocalDateTime.now().plusDays(dayCount+1));
		r.setDropOffLocation(locationRepository.findById(dropOffLocationCode));
		r.setPickUpLocation(locationRepository.findById(pickUpLocationCode));
		r.setMember(memberRepository.findById(memberId));
		r.setCar(carRepository.findByBarcode(carBarcode));
		r.setServices(services);
		r.setEquipments(equipments);
		r.setStatus("ACTIVE");
		Car c = carRepository.findByBarcode(carBarcode);
		c.setStatus("Loaned");
		carRepository.save(c);
		reservationRepository.save(r);
		return MakeReservationMapper.makeReservationToDTO(reservationRepository.findByReservationNumber(r.getReservationNumber()),carRepository.findByBarcode(carBarcode));
		
	}
	
	@Transactional
	public boolean addAdditionalServiceToReservation(int reservationNumber, int serviceCode) {
		com.example.project.model.Service service = serviceRepository.findById(serviceCode);
		if(service == null) {
			return false;
		}
		Reservation r = reservationRepository.findByReservationNumber(reservationNumber);
		r.getServices().add(service);
		reservationRepository.save(r);
		return true;
	}
	@Transactional
	public boolean addAdditionalEquipmentToReservation(int reservationNumber, int equipmentCode) {
		Equipment equipment = equipmentRepository.findById(equipmentCode);
		if(equipment == null) {
			return false;
		}
		Reservation r = reservationRepository.findByReservationNumber(reservationNumber);
		r.getEquipments().add(equipment);
		reservationRepository.save(r);
		return true;
	}
	
	public boolean returnTheCar(int reservationNumber) {
		Reservation reservation = reservationRepository.findByReservationNumber(reservationNumber);
		Car car = reservation.getCar();
		if(java.time.LocalDateTime.now().isBefore(reservation.getDropOffDateAndTime()) || reservation.getDropOffDateAndTime().equals(java.time.LocalDateTime.now())) {
			reservation.setStatus("COMPLETED");
			reservation.setReturnDate(java.time.LocalDate.now());
			car.setStatus("Available");
			carRepository.save(car);
			reservationRepository.save(reservation);
			return true;
		}
		return false;
	}
	
	@Transactional
	public boolean cancelReservation(int reservationNumber) {
		Reservation reservation = reservationRepository.findByReservationNumber(reservationNumber);
		if(reservation != null) {
			Car car = reservationRepository.findById(reservationNumber).get().getCar();
			reservation.setStatus("CANCELLED");
			car.setStatus("Available");
			carRepository.save(car);
			reservationRepository.save(reservation);
			return true;
		}
		return false;
	}
}
