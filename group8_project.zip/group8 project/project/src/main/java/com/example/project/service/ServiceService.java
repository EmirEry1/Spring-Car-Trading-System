package com.example.project.service;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.dto.ServiceDTO;
import com.example.project.mapper.ServiceMapper;
import com.example.project.repository.ServiceRepository;

@Service
public class ServiceService {
    @Autowired
    ServiceRepository serviceRepository;
    
    public ServiceDTO create(ServiceDTO dto){
    	com.example.project.model.Service service = ServiceMapper.DTOtoService(dto);
        serviceRepository.save(service);
        return ServiceMapper.serviceToDTO(service);
    }
    
    public ServiceDTO findById(int id){
    	com.example.project.model.Service service = serviceRepository.findById(id);
        if(service!=null){
            return ServiceMapper.serviceToDTO(service);
        }
        return null;
    }
    
    public List<ServiceDTO> findAllServices(){
        List<com.example.project.model.Service> services = serviceRepository.findAll();
        List<ServiceDTO> serviceDTOs = new ArrayList<ServiceDTO>();
        if(!services.isEmpty()){
            for(int i=0; i<services.size();i++){
                serviceDTOs.add(ServiceMapper.serviceToDTO(services.get(i)));
            }
        }else{
            return null;
        }
        return serviceDTOs;
        
    }


}
