package com.example.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import com.example.project.service.ServiceService;
import com.example.project.dto.ServiceDTO;
import java.util.List;

@RestController()
@RequestMapping(value = "/services")
public class ServiceController {

	@Autowired
	ServiceService serviceS;

	@GetMapping
	public List<ServiceDTO> getAll() {
		return serviceS.findAllServices();
	}

	@GetMapping(value = "/{id}")
	@Operation(summary = "Find service by ID", description = "Returns a single service")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ServiceDTO.class))),
			@ApiResponse(responseCode = "404", description = "Service not found") })
	public ResponseEntity<ServiceDTO> getService(@PathVariable("id") Integer id) {
		ServiceDTO s = serviceS.findById(id);
		if(s != null){
			return ResponseEntity.status(HttpStatus.OK).body(s);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(s);
	}
	
	@PostMapping
	@Operation(summary = "Create a new service", description = "Save new service's info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successful operation") })
	public ResponseEntity<ServiceDTO> saveService(@RequestBody ServiceDTO dto) {
		return ResponseEntity.status(HttpStatus.CREATED).body(serviceS.create(dto));

	}

}
