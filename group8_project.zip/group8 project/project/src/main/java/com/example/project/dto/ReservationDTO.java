package com.example.project.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.example.project.model.Car;
import com.example.project.model.Equipment;
import com.example.project.model.Location;
import com.example.project.model.Member;
import com.example.project.model.Service;

import jakarta.persistence.OneToMany;

public class ReservationDTO {
	private int reservationNumber;
	private LocalDate creationDate;
	private LocalDateTime pickUpDateAndTime;
	private LocalDateTime dropOffDateAndTime;
	private Location pickUpLocation;
	private Location dropOffLocation;
	private LocalDate returnDate;
	private String status;
	private Car car;
	private Member member;
	private List<Service> services;	
	private List<Equipment> equipments;;
	
	
	public List<Service> getServices() {
		return services;
	}
	public void setServices(List<Service> services) {
		this.services = services;
	}
	public List<Equipment> getEquipments() {
		return equipments;
	}
	public void setEquipments(List<Equipment> equipments) {
		this.equipments = equipments;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	public int getReservationNumber() {
		return reservationNumber;
	}
	public void setReservationNumber(int reservationNumber) {
		this.reservationNumber = reservationNumber;
	}
	public LocalDate getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}
	public LocalDateTime getPickUpDateAndTime() {
		return pickUpDateAndTime;
	}
	public void setPickUpDateAndTime(LocalDateTime pickUpDateAndTime) {
		this.pickUpDateAndTime = pickUpDateAndTime;
	}
	public LocalDateTime getDropOffDateAndTime() {
		return dropOffDateAndTime;
	}
	public void setDropOffDateAndTime(LocalDateTime dropOffDateAndTime) {
		this.dropOffDateAndTime = dropOffDateAndTime;
	}
	public Location getPickUpLocation() {
		return pickUpLocation;
	}
	public void setPickUpLocation(Location pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}
	public Location getDropOffLocation() {
		return dropOffLocation;
	}
	public void setDropOffLocation(Location dropOffLocation) {
		this.dropOffLocation = dropOffLocation;
	}
	public LocalDate getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}

}
