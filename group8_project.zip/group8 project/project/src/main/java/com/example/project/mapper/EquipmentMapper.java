package com.example.project.mapper;

import com.example.project.dto.EquipmentDTO;
import com.example.project.model.Equipment;


public class EquipmentMapper {
	public static EquipmentDTO equipmentToDTO(Equipment equipment) {
		EquipmentDTO dto= new EquipmentDTO();
		//dto.setId(equipment.getId());
		dto.setName(equipment.getName());
		dto.setPrice(equipment.getPrice());
		return dto;
	}
	public static Equipment DTOtoEquipment(EquipmentDTO dto) {
		Equipment equipment = new Equipment();
		//equipment.setId(dto.getId());
		equipment.setName(dto.getName());
		equipment.setPrice(dto.getPrice());;
		return equipment;
	}
}
