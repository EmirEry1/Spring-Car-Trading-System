package com.example.project.mapper;

import java.time.Period;

import com.example.project.dto.RentedCarDTO;
import com.example.project.model.Car;
import com.example.project.model.Reservation;

public class RentedCarMapper {
	public static RentedCarDTO rentedCarToDTO(Car c, Reservation r) {
		RentedCarDTO dto= new RentedCarDTO();
		dto.setBarcode(c.getBarcode());
		dto.setBrand(c.getBrand());
		dto.setDropOffDateAndTime(r.getDropOffDateAndTime());
		dto.setDropOffLocation(r.getDropOffLocation());
		dto.setModel(c.getModel());
		dto.setTransmissionType(c.getTransmissionType());
		dto.setType(c.getType());
		dto.setReservationNumber(r.getReservationNumber());
		dto.setMemberName(r.getMember().getName());
		Period difference = Period.between(r.getPickUpDateAndTime().toLocalDate(),r.getDropOffDateAndTime().toLocalDate());
		dto.setReservationDayCount(difference.getDays());
		return dto;
	}
}
