package com.example.project.mapper;



import com.example.project.dto.ReservationDTO;
import com.example.project.model.Reservation;

public class ReservationMapper {
	
	public static ReservationDTO reservationToDTO(Reservation r) {
		ReservationDTO dto= new ReservationDTO();
		dto.setDropOffDateAndTime(r.getDropOffDateAndTime());
		dto.setDropOffLocation(r.getDropOffLocation());
		dto.setPickUpDateAndTime(r.getPickUpDateAndTime());
		dto.setPickUpLocation(r.getPickUpLocation());
		dto.setReservationNumber(r.getReservationNumber());
		dto.setCreationDate(r.getCreationDate());
		dto.setCar(r.getCar());
		dto.setMember(r.getMember());
		dto.setStatus(r.getStatus());
		dto.setReturnDate(r.getReturnDate());
		dto.setServices(r.getServices());
		dto.setEquipments(r.getEquipments());
		return dto;
	}
	
	public static Reservation DTOtoReservation(ReservationDTO dto) {
		Reservation reservation= new Reservation();
		reservation.setDropOffDateAndTime(dto.getDropOffDateAndTime());
		reservation.setDropOffLocation(dto.getDropOffLocation());
		reservation.setPickUpDateAndTime(dto.getPickUpDateAndTime());
		reservation.setPickUpLocation(dto.getPickUpLocation());
		reservation.setReservationNumber(dto.getReservationNumber());
		reservation.setServices(dto.getServices());
		reservation.setReturnDate(dto.getReturnDate());
		reservation.setEquipments(dto.getEquipments());
		reservation.setMember(dto.getMember());
		reservation.setStatus(dto.getStatus());
		reservation.setCar(dto.getCar());
		reservation.setDropOffLocation(dto.getDropOffLocation());
		return reservation;
	}
	
}
