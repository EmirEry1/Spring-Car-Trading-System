package com.example.project.mapper;

import com.example.project.dto.CarDTO;
import com.example.project.dto.GeneralCarDTO;
import com.example.project.model.Car;

public class CarMapper {
	public static CarDTO carToDTO(Car c) {
		CarDTO dto= new CarDTO();
	//	dto.setId(c.getId());
		dto.setBarcode(c.getBarcode());
		dto.setBrand(c.getBrand());
		dto.setMileage(c.getMileage());
		dto.setModel(c.getModel());
		dto.setTransmissionType(c.getTransmissionType());
		dto.setType(c.getType());
		return dto;
	}
	
	public static Car DTOtoCar(CarDTO dto) {
		Car car= new Car();
	//	car.setId(dto.getId());
		car.setBarcode(dto.getBarcode());
		car.setBrand(dto.getBrand());
		car.setMileage(dto.getMileage());
		car.setModel(dto.getModel());
		car.setTransmissionType(dto.getTransmissionType());
		car.setType(dto.getType());
		return car;
	}
	public static GeneralCarDTO generalCarToDTO (Car c) {
		GeneralCarDTO dto= new GeneralCarDTO();
		dto.setBarcode(c.getBarcode());
		dto.setBrand(c.getBrand());
		dto.setMileage(c.getMileage());
		dto.setModel(c.getModel());
		dto.setTransmissionType(c.getTransmissionType());
		dto.setType(c.getType());
		dto.setLicencePlateNumber(c.getLicencePlateNumber());
		dto.setPassengerCapacity(c.getPassengerCapacity());
		dto.setDailyPrice(c.getDailyPrice());
		return dto;
	}
	
	public static Car GeneralDTOtoCar(GeneralCarDTO dto) {
		Car car= new Car();
	//	car.setId(dto.getId());
		car.setBarcode(dto.getBarcode());
		car.setBrand(dto.getBrand());
		car.setMileage(dto.getMileage());
		car.setModel(dto.getModel());
		car.setTransmissionType(dto.getTransmissionType());
		car.setType(dto.getType());
		car.setDailyPrice(dto.getDailyPrice());
		car.setPassengerCapacity(dto.getPassengerCapacity());
		car.setLicencePlateNumber(dto.getLicencePlateNumber());
		return car;
	}
	

	
}
