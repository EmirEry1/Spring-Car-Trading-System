package com.example.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.dto.MemberDTO;
import com.example.project.mapper.MemberMapper;
import com.example.project.model.Member;
import com.example.project.repository.MemberRepository;

@Service
public class MemberService {
	
	@Autowired
	MemberRepository memberRepository;
	
	public MemberDTO create(MemberDTO dto) {
		Member member = MemberMapper.DTOtoMember(dto);
		memberRepository.save(member);
		return MemberMapper.memberToDTO(member);
	}
	
	public MemberDTO findById(int id) {
		Member member=memberRepository.findById(id);
		if( member!= null) {
			return MemberMapper.memberToDTO(member);
		}
		return  null;
	}
	
	public List<MemberDTO> findAllMembers(){
		List<Member> members = memberRepository.findAll();
		List<MemberDTO> memberDTOs = new ArrayList<MemberDTO>();
		if(!members.isEmpty()) {
			for(int i = 0; i<members.size();i++) {
				memberDTOs.add(MemberMapper.memberToDTO(members.get(i)));
			}
		}
		else {
			return null;
		}
		return memberDTOs;
	}
}
