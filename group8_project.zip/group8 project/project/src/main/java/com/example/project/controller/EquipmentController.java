package com.example.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.dto.EquipmentDTO;
import com.example.project.model.Equipment;
import com.example.project.service.EquipmentService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController()
@RequestMapping(value = "/equipments")
public class EquipmentController {
	@Autowired
	EquipmentService service;

	@GetMapping
	public List<EquipmentDTO> getAll() {
		return service.findAllEquipments();
	}
	
	@PostMapping
	@Operation(summary = "Create a new equipment", description = "Save new equipment's info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successful operation") })
	public ResponseEntity<EquipmentDTO> saveEquipment(@RequestBody EquipmentDTO dto) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
	}
	
	@GetMapping(value = "/{id}")
	@Operation(summary = "Find Equipment by ID", description = "Returns a single equipment")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = EquipmentDTO.class))),
			@ApiResponse(responseCode = "404", description = "Equipment not found") })
	public ResponseEntity<EquipmentDTO> getEquipment(@PathVariable("id") Integer id) {
		EquipmentDTO e = service.findById(id);
		if(e != null)
			return ResponseEntity.status(HttpStatus.OK).body(e);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e);
	}
	
}
