package com.example.project.service;

import java.util.ArrayList;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.project.dto.CarDTO;
import com.example.project.dto.GeneralCarDTO;
import com.example.project.dto.RentedCarDTO;
import com.example.project.mapper.CarMapper;
import com.example.project.mapper.RentedCarMapper;
import com.example.project.model.Car;

import com.example.project.model.Reservation;
import com.example.project.repository.CarRepository;
import com.example.project.repository.ReservationRepository;

@Service
public class CarService {
	
	@Autowired
	CarRepository carRepository;
	
	@Autowired
	ReservationRepository reservationRepository;
	
	public GeneralCarDTO create(GeneralCarDTO dto){
		Car c = CarMapper.GeneralDTOtoCar(dto);
		c.setStatus("Available");
		carRepository.save(c);
		return CarMapper.generalCarToDTO(c);
	}
	
	public GeneralCarDTO findById(int id){
		Car c = carRepository.findById(id); 	
		if(c != null)
			return CarMapper.generalCarToDTO(c);
		return null;
	}
	
	public List<GeneralCarDTO> findAllCars(){
		List<Car> cars = carRepository.findAll();
		List<GeneralCarDTO> carDTOs = new ArrayList<GeneralCarDTO>();
		if(cars != null) {
			for(int i = 0; i<cars.size();i++) {
				carDTOs.add(CarMapper.generalCarToDTO(cars.get(i)));
			}
		}
		else {
			return null;
		}
		return carDTOs;
	}
	
	public List<CarDTO> searchAvailableCars(String type, String transmissionType){
		List<Car> cars = carRepository.findByStatusAndTypeAndTransmissionType("Available", type, transmissionType);
		List<CarDTO> carDTOs = new ArrayList<CarDTO>();
		if(!cars.isEmpty()) {
			for(int i = 0; i<cars.size();i++) {
				carDTOs.add(CarMapper.carToDTO(cars.get(i)));
			}
		}
		else {
			return null;
		}
		return carDTOs;
	}
	
	
	public List<RentedCarDTO> getAllRentedCars(){
		java.util.List<String> status = new ArrayList<>();
		status.add("Reserved");
		status.add("Loaned");
		List<Car> cars = carRepository.findByStatusIn(status);
		for (Car car : cars) {
			System.out.println(car);
		}
		List<RentedCarDTO> rentedCarDTOs = new ArrayList<RentedCarDTO>();
		if(!cars.isEmpty()) {
			for(int i = 0; i<cars.size();i++) {
				Reservation reservation = reservationRepository.findByCar(cars.get(i));
				rentedCarDTOs.add(RentedCarMapper.rentedCarToDTO(cars.get(i), reservation));
			}
		}
		else {
			return null;
		}
		return rentedCarDTOs;
	}
	
	public boolean delete(String barcodeNumber) {
		Car car = carRepository.findByBarcode(barcodeNumber);
		Reservation r = reservationRepository.findByCar(car);
		if(car == null || r!=null || !car.getStatus().equals("Available")) {
			return false;
		}	
		int id=car.getId();
		carRepository.deleteById(id);
		return true;
	}
	
	public boolean isCarFound(String barcodeNumber){
		Car car = carRepository.findByBarcode(barcodeNumber);
		if(car!=null) {
			return true;
		}
		return false;
	}
}
