package com.example.project.mapper;

import com.example.project.dto.ServiceDTO;
import com.example.project.model.Service;

public class ServiceMapper {
    public static ServiceDTO serviceToDTO(Service s){
        ServiceDTO dto = new ServiceDTO();
        dto.setName(s.getName());
        dto.setPrice(s.getPrice());
        //dto.setId(s.getId());
        return dto;
    }
    public static Service DTOtoService(ServiceDTO dto) {
		Service service = new Service();
	//	service.setId(dto.getId());
		service.setName(dto.getName());
		service.setPrice(dto.getPrice());;
		return service;
	}
}
