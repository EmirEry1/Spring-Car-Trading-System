package com.example.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.project.dto.CarDTO;
import com.example.project.dto.GeneralCarDTO;
import com.example.project.dto.RentedCarDTO;
import com.example.project.service.CarService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController()
@RequestMapping(value = "/cars")
public class CarController {
	@Autowired
	CarService service;
	
	 /*@GetMapping
	public List<CarDTO> getAllCars() {
		return service.findAllCars();
	}*/
	
	@GetMapping(value = "/{id}")
	@Operation(summary = "Find car by ID", description = "Returns a single car")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = CarDTO.class))),
			@ApiResponse(responseCode = "404", description = "Car not found") })
	public ResponseEntity<GeneralCarDTO> getCar(@PathVariable("id") int id) {
		GeneralCarDTO c = service.findById(id);
		if(c!=null)
			return ResponseEntity.status(HttpStatus.OK).body(c);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(c);
	}
	
	@GetMapping
	public List<GeneralCarDTO> getAll() {
		return service.findAllCars();
	}
	
	@GetMapping(value = "/availablecars")
	@Operation(summary = "Find all available cars", description = "Returns available cars")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = RentedCarDTO.class))),
			@ApiResponse(responseCode = "404", description = "Available cars are not found") })
	public ResponseEntity<List<CarDTO>> searchAvailableCars(@RequestParam("transmission type") String transmissionType, @RequestParam ("type") String type) {
		List<CarDTO> dtos = service.searchAvailableCars(type,transmissionType );
		if(dtos!=null)
			return ResponseEntity.status(HttpStatus.OK).body(dtos);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(dtos);
	} 
	
	@GetMapping(value = "/rentedcars")
	@Operation(summary = "Find all rented cars", description = "Returns rented cars")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = RentedCarDTO.class))),
			@ApiResponse(responseCode = "404", description = "Rented/Reserved cars are not found",content = @Content(schema = @Schema(implementation = RentedCarDTO.class))) })
	public ResponseEntity<List<RentedCarDTO>> getAllRentedCars() {
		List<RentedCarDTO> dtos = service.getAllRentedCars();
		if(dtos != null){
			return ResponseEntity.status(HttpStatus.OK).body(dtos);	
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(dtos);
	}
	
	@PostMapping
	@Operation(summary = "Create a new car", description = "Save new car's' info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successful operation") })
	public ResponseEntity<GeneralCarDTO> saveCar(@RequestBody GeneralCarDTO dto) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
	
	}
	
	@DeleteMapping(value = "/{barcodeNumber}")
	@Operation(summary = "Delete a car", description = "Deletes a car with barcode number")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Successful operation",content = @Content(schema = @Schema(implementation = RentedCarDTO.class))),
			@ApiResponse(responseCode = "404", description = "Car not found"),
			@ApiResponse(responseCode = "500", description = "Throws an Exception"),
			@ApiResponse(responseCode = "406", description = "Car is not available or used in at least one reservation")})
	public ResponseEntity<Boolean> deleteCar(@PathVariable("barcodeNumber") String barcodeNumber){
		Boolean b = null;
		Boolean carFound= service.isCarFound(barcodeNumber);
		
		try{
			b = service.delete(barcodeNumber);
			if(!carFound) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(b);	
			}else if(!b) {
				return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(b);
			}
			return ResponseEntity.status(HttpStatus.OK).body(b);
		}
		catch(Exception e){
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(b);
		}		
		
	}
}