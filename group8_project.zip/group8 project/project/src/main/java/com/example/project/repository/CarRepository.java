package com.example.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.project.model.Car;

@Repository
public interface CarRepository extends JpaRepository<Car, Integer>{
	public Car findById(int id);
	
	public List<Car> findByStatusAndTypeAndTransmissionType(String status, String type, String transmissionType);
	//public Car findById(int id);

	public Car findByBarcode(String barcode);
	
	public List<Car> findByStatusIn(List<String> statuses);
	
	@Query(value = "SELECT * FROM CAR c ", nativeQuery = true)
	public List<Car> findRentedCarCount();
	
	public void deleteByBarcode(String barcode);
	public void deleteById(int id);
}
