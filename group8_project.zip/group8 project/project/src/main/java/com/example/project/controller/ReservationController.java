package com.example.project.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import com.example.project.dto.MakeReservationDTO;
import com.example.project.dto.MakeReservationParameterDTO;
import com.example.project.dto.RentedCarDTO;
import com.example.project.dto.ReservationDTO;

import com.example.project.service.ReservationService;

@RestController()
@RequestMapping(value = "/reservations")
public class ReservationController {
	@Autowired
	ReservationService service;

	@GetMapping
	public List<ReservationDTO> getAll() {
		return service.findAllReservations();
	}
	

	@GetMapping(value = "/{id}")
	@Operation(summary = "Find reservation by ID", description = "Returns a single reservation")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ReservationDTO.class))),
			@ApiResponse(responseCode = "404", description = "Reservation not found") })
	public ResponseEntity<ReservationDTO> getService(@PathVariable("id") Integer id) {
		ReservationDTO r = service.findById(id);
		if(r != null )
			return ResponseEntity.status(HttpStatus.OK).body(r);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
	}
	
	@PostMapping
	@Operation(summary = "Create a new reservation", description = "Save new reservation's info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successful operation") })
	public ResponseEntity<ReservationDTO> saveReservation(@RequestBody ReservationDTO dto) {
		return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
	}
	
	@GetMapping(value = "/returnTheCar/{reservationNumber}")
	@Operation(summary = "Return the car", description = "Returns boolean")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ReservationDTO.class))),
			@ApiResponse(responseCode = "404", description = "Reservation not found"),
			@ApiResponse(responseCode = "500", description = "Throws an exception")})
	public ResponseEntity<Boolean> returnTheCar(@RequestParam("reservationNumber") Integer reservationNumber) {
		Boolean b = null;
		try{
			b = service.returnTheCar(reservationNumber);
			if(b)
				return ResponseEntity.status(HttpStatus.OK).body(b);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(b);	
		}
		catch(Exception e){
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(b);
			
		}
		
	}
	
	@PutMapping(value="/addEquipment")
	@Operation(summary = "Add additional equipment", description = "Returns boolean")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ReservationDTO.class))),
			@ApiResponse(responseCode = "404", description = "Equipment not found"),
			@ApiResponse(responseCode = "500", description = "Throws an exception")})
	public ResponseEntity<Boolean> addAdditionalEquipment(@RequestParam("reservation number") int reservationNumber,@RequestParam("equipment code") Integer equipmentCode) {
		Boolean b = null;
		try{
			b = service.addAdditionalEquipmentToReservation(reservationNumber,equipmentCode);
			if(b)
				return ResponseEntity.status(HttpStatus.OK).body(b);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(b);	
		}
		catch(Exception e){
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(b);
		}
		
	}
	
	@PutMapping(value="/addService")
	@Operation(summary = "Add additional services", description = "Returns boolean")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "successful operation", content = @Content(schema = @Schema(implementation = ReservationDTO.class))),
			@ApiResponse(responseCode = "404", description = "Service not found"),
			@ApiResponse(responseCode = "500", description = "Throws an exception")})
	public ResponseEntity<Boolean> addAdditionalService(@RequestParam("reservation number") Integer reservationNumber,@RequestParam("Additional service code") Integer serviceCode) {
		Boolean b = null;
		try{
			b = service.addAdditionalServiceToReservation(reservationNumber,serviceCode);
			if(b)
				return ResponseEntity.status(HttpStatus.OK).body(b);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(b);	
		}
		catch(Exception e){
			
			System.out.println(e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(b);
		}
		
	}
	
	@PutMapping
	@Operation(summary = "Cancel a reservation", description = "Cancels a reservation with reservation number")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful operation",content = @Content(schema = @Schema(implementation = RentedCarDTO.class))),
			@ApiResponse(responseCode = "404", description = "Reservation not found"),
			@ApiResponse(responseCode = "500", description = "Throws an Exception") })
	public ResponseEntity<Boolean> cancelReservation(@RequestParam("reservationNumber") Integer reservationNumber){		
		Boolean b = null;
		try{
			b = service.cancelReservation(reservationNumber);
			if(b)
				return ResponseEntity.status(HttpStatus.OK).body(b);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(b);	
		}
		catch(Exception e){
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(b);
		}
	}
	
	//Because of we write 2 functions that user can make a reservation, one of them is default reservation, another is makeReservation function 
	//we decided to differentiate these functions making the URL like /reservations/makeReservation
	@PostMapping(value="/makeReservation")
	@Operation(summary = "Make a reservation", description = "Makes a reservation and saves the necessary infos into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Reservation is successfull"),
							@ApiResponse(responseCode = "406", description = "Car is not available")})
	public ResponseEntity<MakeReservationDTO> makeReservation(@RequestBody MakeReservationParameterDTO dto ) {
		MakeReservationDTO dtoForServiceControl = service.makeReservation(dto.getCarBarcodeNumber(),dto.getDayCount(), dto.getMemberId(), dto.getPickUpLocationCode(),dto.getDropOffLocationCode(), dto.getEquipmentList(),dto.getServiceList()); 
		if(dto!=null && dtoForServiceControl!=null) {
			return ResponseEntity.status(HttpStatus.OK).body(dtoForServiceControl);
		}
		return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(dtoForServiceControl);
	}
}
