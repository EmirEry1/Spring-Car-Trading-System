package com.example.project.controller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.dto.MemberDTO;

import com.example.project.service.MemberService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController()
@RequestMapping(value = "/members")
public class MemberController {
	@Autowired
	MemberService service;

	@GetMapping
	public List<MemberDTO> getAll() {
		return service.findAllMembers();
	}
	
	@PostMapping
	@Operation(summary = "Create a new member", description = "Save new member's info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Successful operation") })
	public ResponseEntity<MemberDTO> saveMember(@RequestBody MemberDTO dto) {
		System.out.println(dto.getName());
		return ResponseEntity.status(HttpStatus.CREATED).body(service.create(dto));
	}
	
	@GetMapping(value = "/{id}")
	@Operation(summary = "Find Member by ID", description = "Returns a single member")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = MemberDTO.class))),
			@ApiResponse(responseCode = "404", description = "Member not found") })
	public ResponseEntity<MemberDTO> getMember(@PathVariable("id") Integer id) {
		MemberDTO m = service.findById(id);
		if(m != null)
			return ResponseEntity.status(HttpStatus.OK).body(m);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(m);
	}

}
