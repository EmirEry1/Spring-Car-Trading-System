package com.example.project.mapper;

import org.mapstruct.Mapper;

import com.example.project.dto.LocationDTO;
import com.example.project.model.Location;

@Mapper(componentModel = "spring")
public class LocationMapper {
	public static LocationDTO locationToDTO(Location location){
		LocationDTO dto = new LocationDTO();
	//	dto.setId(location.getId());
		dto.setName(location.getName());
		dto.setAddress(location.getAddress());
		return dto;
	}
	public static Location DTOtoLocation(LocationDTO dto) {
		Location location = new Location();
	//	location.setId(dto.getId());
		location.setName(dto.getName());
		location.setAddress(dto.getAddress());
		return location;
	}
	
}
