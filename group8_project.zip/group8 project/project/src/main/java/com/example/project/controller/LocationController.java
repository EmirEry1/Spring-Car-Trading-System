package com.example.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.project.dto.LocationDTO;
import com.example.project.service.LocationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController()
@RequestMapping(value = "/locations")
public class LocationController {
	@Autowired
	LocationService locationService;
	
	/* @GetMapping
	public List<CarDTO> getAll() {
		return carService.findAllCars();
	}*/
	
	@GetMapping(value = "/{id}")
	@Operation(summary = "Find location by ID", description = "Returns a single location")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Successful operation", content = @Content(schema = @Schema(implementation = LocationDTO.class))),
			@ApiResponse(responseCode = "404", description = "Location not found") })
	public ResponseEntity<LocationDTO> getLocation(@PathVariable("id") int id) {
		LocationDTO l = locationService.findById(id);
		if(l != null)
			return ResponseEntity.status(HttpStatus.OK).body(l);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(l);
	}
	
	@GetMapping
	public List<LocationDTO> getAll() {
		return locationService.findAllLocations();
	}
	
	@PostMapping
	@Operation(summary = "Create a new location", description = "Save new location's info into database")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "successful operation") })
	public ResponseEntity<LocationDTO> saveLocation(@RequestBody LocationDTO location) {
		return ResponseEntity.status(HttpStatus.CREATED).body(locationService.create(location));
	}
}
