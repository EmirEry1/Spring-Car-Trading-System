package com.example.project.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.project.dto.EquipmentDTO;
import com.example.project.mapper.EquipmentMapper;
import com.example.project.model.Equipment;
import com.example.project.repository.EquipmentRepository;


@Service
public class EquipmentService {
	
	@Autowired
	EquipmentRepository equipmentRepository;
	
	@Transactional
	public EquipmentDTO create(EquipmentDTO dto) {
		Equipment equipment = EquipmentMapper.DTOtoEquipment(dto);
		equipmentRepository.save(equipment);
		return EquipmentMapper.equipmentToDTO(equipment);
	}
	
	public EquipmentDTO findById(int id) {
		Equipment equipment=equipmentRepository.findById(id);
		if(equipment!=null) {
			return EquipmentMapper.equipmentToDTO(equipment);
		}
		return  null;
	}
	
	public List<EquipmentDTO> findAllEquipments(){
		List<Equipment> equipments = equipmentRepository.findAll();
		List<EquipmentDTO> equipmentDTOs = new ArrayList<EquipmentDTO>();
		if(!equipments.isEmpty()) {
			for(int i = 0; i<equipments.size();i++) {
				equipmentDTOs.add(EquipmentMapper.equipmentToDTO(equipments.get(i)));
			}
		}
		else {
			return null;
		}
		return equipmentDTOs;
	}
}
