package com.example.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.project.model.Car;
import com.example.project.model.Reservation;
import com.example.project.model.Service;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Integer>{
	public Reservation findByReservationNumber(int reservationNumber);
	public List<Service> findServicesByReservationNumber(int reservationNumber);
	@Query(value= "INSERT INTO RESERVATION_SERVICES (RESERVATION_RESERVATION_NUMBER,SERVICES_ID) VALUES (?1,?2)", nativeQuery = true)
	public void addService(int reservationNumber, int serviceId);
	@Query(value= "INSERT INTO RESERVATION_EQUIPMENTS (RESERVATION_RESERVATION_NUMBER,EQUIPMENTS_ID) VALUES (?1,?2)", nativeQuery = true)
	public void addEquipment(int reservationNumber, int equipmentId);
	//@Query(value = "SELECT * FROM RESERVATION r WHERE r.CAR_BARCODE = ?1 AND (r.STATUS = 'LOANED' OR r.STATUS = 'RESERVED')", nativeQuery = true)
	public Reservation findByCar(Car car);
}
