package com.example.project.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import com.example.project.model.Equipment;
import com.example.project.model.Location;
import com.example.project.model.Service;

public class MakeReservationDTO {
	
	private int reservationNumber;
	private LocalDateTime pickUpDateAndTime;
	private LocalDateTime dropOffDateAndTime;
	private Location pickUpLocation;
	private Location dropOffLocation;
	private LocalDate returnDate;
	private double totalAmount;
	private List<Service> services;
	private List<Equipment> equipments;
	
	public MakeReservationDTO(){
		super();
	}

	public int getReservationNumber() {
		return reservationNumber;
	}

	public void setReservationNumber(int reservationNumber) {
		this.reservationNumber = reservationNumber;
	}
	public LocalDateTime getPickUpDateAndTime() {
		return pickUpDateAndTime;
	}

	public void setPickUpDateAndTime(LocalDateTime pickUpDateAndTime) {
		this.pickUpDateAndTime = pickUpDateAndTime;
	}

	public LocalDateTime getDropOffDateAndTime() {
		return dropOffDateAndTime;
	}

	public void setDropOffDateAndTime(LocalDateTime dropOffDateAndTime) {
		this.dropOffDateAndTime = dropOffDateAndTime;
	}

	public Location getPickUpLocation() {
		return pickUpLocation;
	}

	public void setPickUpLocation(Location pickUpLocation) {
		this.pickUpLocation = pickUpLocation;
	}

	public Location getDropOffLocation() {
		return dropOffLocation;
	}

	public void setDropOffLocation(Location dropOffLocation) {
		this.dropOffLocation = dropOffLocation;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<Service> getServices() {
		return services;
	}

	public void setServices(List<Service> services) {
		this.services = services;
	}

	public List<Equipment> getEquipments() {
		return equipments;
	}

	public void setEquipments(List<Equipment> equipments) {
		this.equipments = equipments;
	}
	

}
