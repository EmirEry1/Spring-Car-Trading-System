package com.example.project.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import com.example.project.model.Equipment;
import com.example.project.model.Service;

public class MakeReservationParameterDTO {
	private String carBarcodeNumber;
	private int dayCount;
	private int memberId;
	private int pickUpLocationCode;
	private int dropOffLocationCode;
	private List<Integer> equipmentList;
	private List<Integer> serviceList;
	public String getCarBarcodeNumber() {
		return carBarcodeNumber;
	}
	public void setCarBarcodeNumber(String carBarcodeNumberm) {
		this.carBarcodeNumber = carBarcodeNumberm;
	}
	public int getDayCount() {
		return dayCount;
	}
	public void setDayCount(int dayCount) {
		this.dayCount = dayCount;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getPickUpLocationCode() {
		return pickUpLocationCode;
	}
	public void setPickUpLocationCode(int pickUpLocationCode) {
		this.pickUpLocationCode = pickUpLocationCode;
	}
	public int getDropOffLocationCode() {
		return dropOffLocationCode;
	}
	public void setDropOffLocationCode(int dropOffLocationCode) {
		this.dropOffLocationCode = dropOffLocationCode;
	}
	public List<Integer> getEquipmentList() {
		return equipmentList;
	}
	public void setEquipmentList(List<Integer> equipmentList) {
		this.equipmentList = equipmentList;
	}
	public List<Integer> getServiceList() {
		return serviceList;
	}
	public void setServiceList(List<Integer> serviceList) {
		this.serviceList = serviceList;
	}
	

}
