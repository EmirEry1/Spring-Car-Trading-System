package com.example.project.mapper;

import java.time.Period;
import java.util.List;

import com.example.project.dto.MakeReservationDTO;
import com.example.project.model.Car;
import com.example.project.model.Equipment;
import com.example.project.model.Reservation;
import com.example.project.model.Service;

public class MakeReservationMapper {
	public static MakeReservationDTO makeReservationToDTO(Reservation r, Car c) {
		MakeReservationDTO dto= new MakeReservationDTO();
		double totalAmount =0;
		dto.setDropOffDateAndTime(r.getDropOffDateAndTime());
		dto.setDropOffLocation(r.getDropOffLocation());
		dto.setPickUpDateAndTime(r.getPickUpDateAndTime());
		dto.setPickUpLocation(r.getPickUpLocation());
		dto.setReservationNumber(r.getReservationNumber());
		Period difference = Period.between(r.getPickUpDateAndTime().toLocalDate(),r.getDropOffDateAndTime().toLocalDate());
		totalAmount +=c.getDailyPrice()*difference.getDays();
		dto.setEquipments(r.getEquipments());
		dto.setServices(r.getServices());
		List<Equipment> equipmentList = r.getEquipments();
		if(equipmentList.size()!=0) {
			
			for (Equipment equipment : equipmentList) {
				totalAmount +=equipment.getPrice();
			}
		}
		if(r.getServices().size()!=0) {
			for(Service s : r.getServices()){
				totalAmount +=s.getPrice();
			}
		}
		dto.setTotalAmount(totalAmount);
		return dto;
	}

}